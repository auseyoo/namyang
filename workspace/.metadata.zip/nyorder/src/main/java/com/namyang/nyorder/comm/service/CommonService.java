package com.namyang.nyorder.comm.service;

import java.util.List;

import com.namyang.nyorder.comm.vo.CstMstVO;

public interface CommonService {

	public List<CstMstVO> selectAddr(CstMstVO cstMstVO);

}
