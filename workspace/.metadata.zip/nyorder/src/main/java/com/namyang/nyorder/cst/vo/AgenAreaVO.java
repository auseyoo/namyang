package com.namyang.nyorder.cst.vo;

import lombok.Setter;
import lombok.Getter;

@Getter
@Setter
public class AgenAreaVO {
	
	private String agenSeq;
	private String areaSeq;
	private String areaNm;
	private String agenAreaCd;
}
