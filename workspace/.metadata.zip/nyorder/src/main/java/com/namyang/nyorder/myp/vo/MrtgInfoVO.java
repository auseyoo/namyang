package com.namyang.nyorder.myp.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MrtgInfoVO {

	
	private String agenSeq;
	private String emplSeq;
}
