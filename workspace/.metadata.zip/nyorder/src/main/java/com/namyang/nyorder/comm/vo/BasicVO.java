package com.namyang.nyorder.comm.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BasicVO {
	
	private String queryId;
	
	private Class resultClass;
	private Object paramClass;

}
