package com.namyang.nyorder.config.exception;

public class CustomAjaxException extends RuntimeException{
	
	public CustomAjaxException() {
		super("ajax Exception");
	}
}
