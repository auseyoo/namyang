package com.namyang.nyorder.cst.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CstCntrVO {

	private String prdNm;
	private String prdDtlCd;
	private String stdrQty;
	private String hop;
	private String cntrMonth;
	private String statDt;
	private String remrDt;
	private String qtys;
	private String prmt;
}
